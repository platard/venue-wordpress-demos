<?php
require '/wordpress/wp-load.php';

update_option('blogname', 'The Lantern Room');
update_option('blogdescription', 'Independent live music in Ottawa');
update_option('timezone_string', 'America/Toronto');

$room_photo = esc_url(get_theme_file_uri('assets/room.jpg'));
$pages = [
    'home' => ['Home', <<<'HTML'
<section aria-labelledby="upcoming">
<p class="eyebrow">The next three shows</p>
<h2 id="upcoming">Coming up at The Lantern Room</h2>
[venue_showtimes]
</section>
HTML],
    'whats-on' => ['What’s On', <<<'HTML'
<p>Discover intimate jazz sets, daytime sessions and acoustic nights. All showtimes are listed in Ottawa local time.</p>
<h2>Upcoming performances</h2>
[venue_showtimes]
<p>Doors open 30 minutes before each performance. Seating is general admission.</p>
HTML],
    'about' => ['About', <<<HTML
<p class="eyebrow">The room &amp; the people</p>
<p>The Lantern Room is a fictional independent listening room in Ottawa. It imagines a space where local artists can play an honest set and audiences can hear every note.</p>
<figure class="about-photo"><img src="$room_photo" alt="Amber wall lights over burgundy booths and walnut tables" loading="lazy"></figure>
<h2>What we book</h2>
<p>Small jazz ensembles, acoustic songwriters and emerging acts from across the Ottawa–Gatineau region. Our fictional program mixes evening sets with daytime matinees.</p>
<h2>What to expect</h2>
<p>Unassigned seating, a room designed for attentive listening, and enough time between sets to meet the artists.</p>
HTML],
    'contact' => ['Contact', <<<'HTML'
<p class="eyebrow">Plan your visit</p>
<p>Have a question about visiting, performing or bringing a group? Here’s the information a visitor would find before a show.</p>
<div class="contact-grid">
<section><h2>Visiting</h2><p>Ottawa, Ontario</p><p>Doors open 30 minutes before each listed show. Check the schedule for the next opening time.</p></section>
<section><h2>Access</h2><p>The venue concept includes step-free entry and accessible seating. Seating is general admission.</p></section>
<section><h2>Artist enquiries</h2><p>For a booking enquiry, prepare an artist bio, a live recording, and two or three dates that work for your group.</p></section>
</div>
<p class="demo-note"><strong>Portfolio demo.</strong> The Lantern Room is fictional. There is no physical address or booking service.</p>
HTML],
];

$ids = [];
foreach ($pages as $slug => [$title, $content]) {
    $existing = get_page_by_path($slug);
    $ids[$slug] = wp_insert_post([
        'ID' => $existing ? $existing->ID : 0,
        'post_type' => 'page',
        'post_status' => 'publish',
        'post_name' => $slug,
        'post_title' => $title,
        'post_content' => wp_slash($content),
        'comment_status' => 'closed',
    ], true);
    if (is_wp_error($ids[$slug])) {
        throw new RuntimeException($ids[$slug]->get_error_message());
    }
}

update_option('page_on_front', $ids['home']);
update_option('show_on_front', 'page');

$menu = wp_get_nav_menu_object('Main navigation');
$menu_id = $menu ? $menu->term_id : wp_create_nav_menu('Main navigation');
if (is_wp_error($menu_id)) {
    throw new RuntimeException($menu_id->get_error_message());
}
$items = wp_get_nav_menu_items($menu_id) ?: [];
$items_by_page = array_column($items, 'ID', 'object_id');

foreach (array_values($ids) as $position => $id) {
    $item_id = wp_update_nav_menu_item($menu_id, $items_by_page[$id] ?? 0, [
        'menu-item-object-id' => $id,
        'menu-item-object' => 'page',
        'menu-item-type' => 'post_type',
        'menu-item-status' => 'publish',
        'menu-item-position' => $position + 1,
    ]);
    if (is_wp_error($item_id)) {
        throw new RuntimeException($item_id->get_error_message());
    }
}
set_theme_mod('nav_menu_locations', ['primary' => $menu_id]);
