<?php get_header(); ?>
<main id="main" class="shell inner" tabindex="-1">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <article <?php post_class(); ?>>
    <?php if (is_singular()) : ?>
      <h1><?php the_title(); ?></h1>
      <?php the_content(); ?>
    <?php else : ?>
      <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
      <?php the_excerpt(); ?>
    <?php endif; ?>
  </article>
<?php endwhile; the_posts_pagination(); else : ?>
  <h1>Page unavailable</h1>
  <p><a href="<?php echo esc_url(home_url('/')); ?>">Return to the homepage</a></p>
<?php endif; ?>
</main>
<?php get_footer(); ?>
