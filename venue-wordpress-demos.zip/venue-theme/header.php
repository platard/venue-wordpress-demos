<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#main">Skip to content</a>
<header class="masthead">
  <div class="shell topbar">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><span class="mark" aria-hidden="true">✦</span> The Lantern Room</a>
    <nav aria-label="Main navigation">
      <?php wp_nav_menu(['theme_location' => 'primary', 'container' => false, 'fallback_cb' => false]); ?>
    </nav>
  </div>
</header>
