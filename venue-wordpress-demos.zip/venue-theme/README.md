# The Lantern Room

WordPress theme for a fictional Ottawa listening room. It provides a custom
homepage, a registered main-navigation menu, and a shared template for the
interior pages. The companion Venue Showtimes Demo plugin provides the event
schedule. The Playground blueprint sets up both components and four editable
WordPress pages. The venue photos were generated for this portfolio demo.
