<?php
defined('ABSPATH') || exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    register_nav_menu('primary', 'Main navigation');
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('lantern-room', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
});

function lantern_page_url($slug) {
    $page = get_page_by_path($slug);
    return $page ? get_permalink($page) : home_url('/');
}

function lantern_photo_url($filename) {
    return get_theme_file_uri('assets/' . $filename);
}
