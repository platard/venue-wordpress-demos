<?php get_header(); ?>
<main id="main" tabindex="-1">
  <section class="hero">
    <img src="<?php echo esc_url(lantern_photo_url('stage.jpg')); ?>" alt="" fetchpriority="high">
    <div class="shell hero-copy">
      <p class="eyebrow">Independent live music · Ottawa</p>
      <h1>Good music.<br>Close enough to feel.</h1>
      <p>Jazz, acoustic sets, and new voices in an intimate listening room.</p>
      <a class="button" href="<?php echo esc_url(lantern_page_url('whats-on')); ?>">Explore what’s on <span aria-hidden="true">↗</span></a>
    </div>
  </section>
  <div class="shell home-content">
    <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
    <section class="story">
      <img src="<?php echo esc_url(lantern_photo_url('room.jpg')); ?>" alt="Burgundy seating and amber lamps in the listening room" loading="lazy">
      <div>
        <p class="eyebrow">About the room</p>
        <h2>A room made for listening.</h2>
        <p>Pull up a chair, settle in, and hear Ottawa’s independent music scene up close.</p>
        <a class="text-link" href="<?php echo esc_url(lantern_page_url('about')); ?>">Get to know us <span aria-hidden="true">↗</span></a>
      </div>
    </section>
  </div>
</main>
<?php get_footer(); ?>
