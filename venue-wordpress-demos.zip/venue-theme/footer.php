<footer class="site-footer">
  <div class="shell footer-inner">
    <div><a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><span class="mark" aria-hidden="true">✦</span> The Lantern Room</a><p>Intimate live music in Ottawa, Ontario.</p></div>
    <div><a href="<?php echo esc_url(lantern_page_url('whats-on')); ?>">What’s on</a><a href="<?php echo esc_url(lantern_page_url('contact')); ?>">Plan your visit</a></div>
    <p class="fine">Fictional venue · WordPress portfolio demo</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
