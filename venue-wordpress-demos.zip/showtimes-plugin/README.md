# Venue Showtimes Demo

A WordPress plugin that renders a fictional schedule with the site's time zone and escaped HTML output. Dates are relative to today.

Upload the plugin ZIP under Plugins → Add New → Upload Plugin, then activate it. Add a Shortcode block with `[venue_showtimes limit="2"]` and preview the page. Verify that two performances appear, then remove the limit to display all three.

Portfolio demo created with Codex assistance.
