<?php
/**
 * Plugin Name: Venue Showtimes Demo
 * Description: Display a fictional performance schedule with a shortcode.
 * Version: 1.0
 */
defined('ABSPATH') || exit;

add_shortcode('venue_showtimes', function ($attributes) {
    $attributes = shortcode_atts(['limit' => 3], $attributes, 'venue_showtimes');
    $limit = max(1, min(3, (int) $attributes['limit']));
    $now = current_datetime();
    $shows = [
        ['Midnight Jazz', $now->modify('+1 day')->setTime(19, 30)],
        ['Afternoon Matinee', $now->modify('+3 days')->setTime(14, 0)],
        ['Acoustic Sessions', $now->modify('+7 days')->setTime(20, 0)],
    ];
    $items = [];
    foreach (array_slice($shows, 0, $limit) as [$title, $starts]) {
        $items[] = sprintf(
            '<li><strong>%s</strong> <time datetime="%s">%s</time></li>',
            esc_html($title),
            esc_attr($starts->format(DATE_ATOM)),
            esc_html(wp_date('D, M j · g:i a', $starts->getTimestamp(), wp_timezone()))
        );
    }
    return '<ul class="venue-showtimes">' . implode('', $items) . '</ul>';
});
