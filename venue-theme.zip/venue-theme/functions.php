<?php
defined('ABSPATH') || exit;
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('venue-guide-demo', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
});
