# Venue Guide Demo

A responsive classic WordPress theme for a fictional live venue. It shows excerpts in the listings and full content on individual pages. It includes visible keyboard focus and a skip link.

Upload the theme ZIP under Appearance → Themes → Add New → Upload Theme, then activate it. Create two sample posts and check the home page and an individual post at desktop and mobile widths. Use Tab to test the skip link.

Portfolio demo created with Codex assistance.
