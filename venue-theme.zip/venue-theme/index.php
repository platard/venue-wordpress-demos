<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header><div class="wrap">
<a href="#main">Skip to content</a>
<p><a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
<h1><?php echo esc_html(is_singular() ? get_the_title() : 'What’s on'); ?></h1>
</div></header>
<main class="wrap" id="main" tabindex="-1">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<article <?php post_class(); ?>>
<?php if (is_singular()) : the_content(); else : ?>
<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
<?php the_excerpt(); endif; ?>
</article>
<?php endwhile; the_posts_pagination(); else : ?>
<p>No announcements yet.</p>
<?php endif; ?>
</main>
<?php wp_footer(); ?>
</body>
</html>
